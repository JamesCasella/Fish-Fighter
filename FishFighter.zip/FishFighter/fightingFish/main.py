import pygame
from fighter import Fighter
pygame.init()

#creating the game window

SCREEN_WIDTH = 1026
SCREEN_HEIGHT = 576

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("FISH FIGHTER")

#set frame rate
clock = pygame.time.Clock()
FPS = 30
game_state = "menu"

#colors
RED = (255,0,0)
YELLOW = (255,255,0)
WHITE = (255,255,255)

#game variables
intro_countdown = 3
last_count_update = pygame.time.get_ticks()
score = [0,0]#player scpres 
round_over = False
ROUND_OVER_COOLDOWN = 400

#define fighter variable
red_size = 64
red_scale = 5
red_offset = [25,20]
red_data = [red_size, red_scale, red_offset]
blue_size = 64
blue_scale = 5
blue_offset = [23,20]
blue_data = [blue_size, blue_scale, blue_offset]

#loading background image
bg_image = pygame.image.load("assets/images/background/fisherfightstart-1.png.png").convert_alpha()

#start menu
start_image = pygame.image.load("assets/images/background/fisherfightstart.png").convert_alpha()

#load spritesheets
red_sheet = pygame.image.load("assets/images/red/reddd.png").convert_alpha()
blue_sheet = pygame.image.load("assets/images/blue/bluee.png").convert_alpha()

victory_img = pygame.image.load("assets/images/background/victory.png")

#number of steps in each animations
red_animation_steps = [5,2,4]
blue_animation_steps = [4,2,4]

#fonts
count_font = pygame.font.Font("assets/fonts/American Captain.ttf", 80)
score_font = pygame.font.Font("assets/fonts/American Captain.ttf", 30)

def draw_menu():
    screen.fill((0, 0, 0))

    # make the image bigger
    start_img = pygame.transform.scale(start_image, (1026, 576))

    # center the image
    start_rect = start_img.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))

    screen.blit(start_img, start_rect)

    return start_rect


def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img,(x,y))

#function for drawing the background
def draw_bg():
    scaled_bg = pygame.transform.scale(bg_image, (SCREEN_WIDTH,SCREEN_HEIGHT))
    screen.blit(scaled_bg, (0,0)) 

#fighter healthbars
def draw_health_bar(health, x, y):
    ratio = health / 100
    pygame.draw.rect(screen,WHITE,(x+9,y+8,405, 34))
    pygame.draw.rect(screen,RED,(x+11,y+10,400, 30))
    pygame.draw.rect(screen,YELLOW,(x+11,y+10,400 * ratio, 30))

#create two fighters (fighter 1 = blue, fighter 2 = red)
fighter_1 = Fighter(1, 200,310, False, red_data, red_sheet, red_animation_steps)
fighter_2 = Fighter(2, 700,310, True, blue_data, blue_sheet, blue_animation_steps)

#gameLoop
run = True
while run:

    clock.tick(FPS)

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False

        if game_state == "menu":

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                # START button area
                button_rect = pygame.Rect(0,0,1026,576)
                if button_rect.collidepoint(mouse_pos):
                    game_state = "game"
    if game_state == "menu":

        draw_menu()

    elif game_state == "game":
        draw_bg()

        draw_health_bar(fighter_1.health, 20, 20)
        draw_health_bar(fighter_2.health, 580, 20)
        draw_text("P1: " + str(score[0]), score_font, RED, 30, 70)
        draw_text("P2: " + str(score[1]), score_font, RED, 590, 70)

        if intro_countdown <= 0:
            print(intro_countdown)
            fighter_1.move(SCREEN_WIDTH, SCREEN_HEIGHT, screen, fighter_2, round_over) 
            fighter_2.move(SCREEN_WIDTH, SCREEN_HEIGHT, screen, fighter_1, round_over) 
        else:
            #display timer
            draw_text(str(intro_countdown), count_font, RED, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3 )

            def draw_menu():
                draw_bg()
                
            if(pygame.time.get_ticks() - last_count_update) >= 1000:
                intro_countdown -= 1
                last_count_update = pygame.time.get_ticks()


        #update fighters
        fighter_1.update()
        fighter_2.update()    

        fighter_1.draw(screen)
        fighter_2.draw(screen)


        #check for player defeat
        if round_over == False:
            if fighter_1.alive == False:
                score[1] += 1
                round_over = True
                round_over_time = pygame.time.get_ticks()
            elif fighter_2.alive == False:
                score[0] += 1
                round_over = True
                round_over_time = pygame.time.get_ticks()
        else:
            screen.blit(victory_img, (360, 150))
            if pygame.time.get_ticks() - round_over_time > ROUND_OVER_COOLDOWN:
                round_over = False
                intro_countdown = 3
                fighter_1 = Fighter(1, 200,310, False, red_data, red_sheet, red_animation_steps)
                fighter_2 = Fighter(2, 700,310, True, blue_data, blue_sheet, blue_animation_steps)

    #quit if game is closed 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False 

    #animatates and updates display
    pygame.display.update()

pygame.quit()